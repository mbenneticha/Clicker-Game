# Clicker-Game
An animal-themed clicker game using Android Studio, Java, and XML
